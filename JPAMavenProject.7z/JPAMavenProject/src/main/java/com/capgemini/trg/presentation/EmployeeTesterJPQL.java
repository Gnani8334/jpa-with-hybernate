package com.capgemini.trg.presentation;

import java.util.Iterator;
import java.util.List;

import javax.management.Query;
import javax.persistence.EntityManager;

import com.capgemini.jpa.entity.Employee;
import com.capgemini.jpa.utility.JPAUtil;

public class EmployeeTesterJPQL {

	public static void main(String[] args) 
	{
		EntityManager entityManager=JPAUtil.getEntityManager();
		/*String jpql1="select e from Employee e"; 
		TypedQuery<Employee> typedQuery=entityManager.createQuery(jpql1,Employee.class);
		List<Employee> empList=typedQuery.getResultList();
		showEmployees(empList);*/
		
		//show employee based on job condition
		//pjob  and psal are named parameter
		/*
		String jpql1="select e from Employee e where e.job=:ptitle AND e.salary>:psal";
		TypedQuery<Employee> typedQuery=entityManager.createQuery(jpql1,Employee.class).setParameter("ptitle","Manager").setParameter("psal",5000.00);
		
		//typedQuery.setParameter("ptitle","Manager");
		List<Employee> employee=typedQuery.getResultList();
		showEmployees(employee);
		
		System.out.println(employee);*/
	//named parameters
		/*javax.persistence.Query query1=entityManager.createNamedQuery("q2");
		
		List<Employee> employee=query1.getResultList();
		showEmployees(employee);*/
		//ordinal parameters
		/*String jql2="select e from Employee e where e.job=?1 AND e.deptno=?2";
		TypedQuery<Employee> typedQuery=entityManager.createQuery(jql2,Employee.class).setParameter(1,"Manager").setParameter(2,10);
		List<Employee> employee=typedQuery.getResultList();
		showEmployees(employee);*/
		//native queries
		javax.persistence.Query query=entityManager.createNativeQuery("select * from employee where job=?",Employee.class);
		query.setParameter(1,"Manager");
		List<Employee> employee=query.getResultList();
		showEmployees(employee);
		
	}

	private static void showEmployees(List<Employee> empList) 
	{
		Iterator<Employee> iterator=empList.iterator();
		while(iterator.hasNext())
		{
			System.out.println(iterator.next());
		}
		
	}

}
