package com.capgemini.jpa.presentation;

import java.util.GregorianCalendar;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

import com.capgemini.jpa.entity.Employee;
import com.capgemini.jpa.exception.EmployeeException;
import com.capgemini.jpa.service.EmployeeServiceImpl;
import com.capgemini.jpa.service.IEmployeeService;

public class EmployeeTester {
	private static IEmployeeService employeeService=
								new EmployeeServiceImpl();
	static Scanner scanner=new Scanner(System.in);
	static Employee employee=
		    new Employee(null,"Gnani",new GregorianCalendar(2016,10,15),"Manager",65750.0,10);
		
		
	
	public static void main(String[] args) {
		
		System.out.println("1.ADD EMPLOYEE");
		System.out.println("2.DELETE EMPLOYEE");
		System.out.println("3.UPDATE EMPLOYEE");
		System.out.println("4.GET PARTICULAR EMPLOYEE DETAILS");
		System.out.println("5.GET ALL EMPLOYEE DETAILS");
		System.out.println("6.EXIT");
		System.out.println("select your choice");
		int ch=scanner.nextInt();
		switch(ch)
		{
		
		case 1:  System.out.println("ADD EMPLOYEE");
		        addNewEmployee(employee);
		          break;
		case 2:System.out.println("DELETE EMPLOYEE");
		        System.out.println("enter the employee id");
		        int empid=scanner.nextInt();
		        deleteEmployee(empid);
		        break;
		case 3:Employee employee2=
			    new Employee(null,"Gnani1",new GregorianCalendar(2016,10,15),"Manager",65750.0,10);
		updateEmployee(employee2);
		break;
		
		case 4:System.out.println("GET PARTICULAR EMPLOYEE DETAILS");
		
		 System.out.println("enter the employee id");
	        int empid1=scanner.nextInt();
	        getEmployeeDetails(empid1);
	        break;
		case 5:System.out.println("GET ALL EMPLOYEE DETAILS");
			for (Iterator<Employee> iterator = getAllEmployees(employee).iterator(); iterator
					.hasNext();) {
				Employee employee = iterator.next();
				System.out.println(employee);
			}
	         break;
		case 6:System.exit(0);
		break;
		}
		
		
		
	}

	private static void updateEmployee(Employee employee2) {
		// TODO Auto-generated method stub
		try {
			employeeService.updateEmployee(employee);
		} catch (EmployeeException e) {			
			e.printStackTrace();
		}
	}

	private static List<Employee> getAllEmployees(Employee employee) {
		// TODO Auto-generated method stub
		try {
			for (Iterator<Employee> iterator = employeeService.getAllEmployees(employee).iterator(); iterator
					.hasNext();) {
				Employee employee2 = iterator.next();
				return (List<Employee>) employee2;
			}
		} catch (EmployeeException e) {			
			e.printStackTrace();
		}
		return (List<Employee>) employee;
	}

	private static void addNewEmployee(Employee employee) {
		try {
			employeeService.addNewEmployee(employee);
		} catch (EmployeeException e) {			
			e.printStackTrace();
		}
		
	}
	private static void deleteEmployee(Integer empid)
	{
		try {
		employeeService.deleteEmployee(empid);
	} catch (EmployeeException e) {			
		e.printStackTrace();
	}
	
		}
	public static Employee getEmployeeDetails(Integer empid)
	{
		try {
			employeeService.getEmployeeDetails(empid);
		} catch (EmployeeException e) {			
			e.printStackTrace();
		}
		return employee;
	}

}
